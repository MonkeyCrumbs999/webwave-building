const hamX1 = document.querySelector(".ham-x1");
const hamX2 = document.querySelector(".ham-x2");
const hamMenu = document.getElementById("hamMenu");
const mobileMenu = document.getElementById("mobile-menu");

function toggleMenu() {
  hamX1.classList.toggle("translate-y-1");
  hamX1.classList.toggle("rotate-45");
  hamX2.classList.toggle("w-6");
  hamX2.classList.toggle("-translate-y-1");
  hamX2.classList.toggle("-rotate-45");
  hamX2.classList.toggle("w-4");
  mobileMenu.classList.toggle("invisible");
  mobileMenu.classList.toggle("opacity-0");
  mobileMenu.classList.toggle("opacity-100");
}

// A flag to indicate if the menu is open or not
let menuOpen = false;

// A function to close the menu if it is open
function closeMenu() {
  if (menuOpen) {
    toggleMenu();
    menuOpen = false;
  }
}

// Add a click event listener to the hamburger menu
hamMenu.addEventListener("click", function () {
  // Toggle the menu and update the flag
  toggleMenu();
  menuOpen = !menuOpen;
});

// Add a click event listener to the document
document.addEventListener("click", function (event) {
  // Check if the clicked element is outside of the hamburger menu
  // and its children using contains()
  if (!hamMenu.contains(event.target)) {
    // Close the menu if it is open
    closeMenu();
  }
});
let observer = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("wiggle");
      }
    });
  },
  { threshold: 1.0 }
);

document.querySelectorAll(".why-choose-us, .our-process").forEach((img) => {
  observer.observe(img);
});

document
  .getElementById("darkModeToggle")
  .addEventListener("click", function () {
    document.documentElement.classList.toggle("dark");
  });

//end dark mode

//carousel

document.addEventListener("DOMContentLoaded", function () {
  let slideIndex = 0;
  let timeout;

  const carouselWrapper = document.querySelector("[data-te-carousel-init]");
  const carouselSlides = Array.from(
    carouselWrapper.querySelectorAll("[data-te-carousel-item]")
  );
  const carouselButtons = Array.from(
    carouselWrapper.querySelectorAll("[data-te-slide]")
  );

  // Update slide index
  function updateSlideIndex(n) {
    slideIndex += n;
    if (slideIndex > carouselSlides.length - 1) slideIndex = 0;
    if (slideIndex < 0) slideIndex = carouselSlides.length - 1;
  }

  // Navigate to slide
  function navigateToSlide(n) {
    clearTimeout(timeout);
    carouselSlides.forEach((slide, index) => {
      if (index === n) {
        slide.style.transform = "translateX(0)";
        slide.classList.remove("hidden");
      } else {
        slide.style.transform = "translateX(100%)";
        slide.classList.add("hidden");
      }
    });

    slideIndex = n;
    carouselTransition();
  }

  // Navigate to next/prev slide
  function navigateSlides(n) {
    clearTimeout(timeout);
    updateSlideIndex(n);
    navigateToSlide(slideIndex);
    carouselTransition();
  }

  // Auto transition
  function carouselTransition() {
    timeout = setTimeout(() => navigateSlides(1), 4000); // Change slide every 4 seconds
  }

  // Attach event listeners to each button
  carouselButtons.forEach((button) => {
    if (button.hasAttribute("data-te-slide-to")) {
      button.addEventListener("click", () =>
        navigateToSlide(parseInt(button.getAttribute("data-te-slide-to")))
      );
    } else {
      button.addEventListener("click", () =>
        navigateSlides(button.getAttribute("data-te-slide") === "next" ? 1 : -1)
      );
    }
  });

  navigateToSlide(0); // Initialize carousel at first slide
});
